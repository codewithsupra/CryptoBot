package core

// BitcoinDonationAddress is the GoCryptoTrader BTC donation address
const BitcoinDonationAddress = "bc1qk0jareu4jytc0cfrhr5wgshsq8282awpavfahc"
